'use client'
import { useState, useEffect, useRef } from 'react'
import { supabase } from '@/lib/supabase'
import { LiveBadge, FreeTag, PremTag } from '@/components/ui/tags'
import { VideoPlayer } from '@/components/player/VideoPlayer'
import type { Match, Video, Profile } from '@/types'

/* ── RANKINGS (static for now) ── */
const RANKINGS = [
  { r:1, pair:"Åhman / Hellvig",     flag:"🇸🇪", pts:8200, tr:"▲" },
  { r:2, pair:"Mol / Sørum",         flag:"🇳🇴", pts:8060, tr:"—" },
  { r:3, pair:"Oliveira / Lanci",    flag:"🇧🇷", pts:7820, tr:"▲" },
  { r:4, pair:"Nilsson / Andersson", flag:"🇸🇪", pts:7760, tr:"▲" },
  { r:5, pair:"Boermans / De Groot", flag:"🇳🇱", pts:7520, tr:"▼" },
  { r:6, pair:"Younousse / Tijan",   flag:"🇶🇦", pts:6740, tr:"—" },
  { r:7, pair:"Pļaviņš / Fokerots", flag:"🇱🇻", pts:6280, tr:"▲" },
  { r:8, pair:"Bassereau / Ayé",     flag:"🇫🇷", pts:6140, tr:"▲" },
  { r:9, pair:"Ehlers / Wickler",    flag:"🇩🇪", pts:6120, tr:"▼" },
  { r:10, pair:"Łosiak / Bryl",      flag:"🇵🇱", pts:6260, tr:"▲" },
]

const LEAGUES = [
  { id:"all",   label:"Tutti",    flag:"🌐" },
  { id:"bpt",   label:"BPT",      flag:"🏆" },
  { id:"fipav", label:"FIPAV",    flag:"🇮🇹" },
  { id:"aibvc", label:"AIBVC",    flag:"🏐" },
  { id:"ffvb",  label:"Francia",  flag:"🇫🇷" },
  { id:"rfevb", label:"Spagna",   flag:"🇪🇸" },
  { id:"avp",   label:"AVP",      flag:"🇺🇸" },
]

/* ── CSS ── */
const S = {
  shell: { maxWidth:430, margin:'0 auto', minHeight:'100dvh', background:'var(--bg)', display:'flex', flexDirection:'column' as const, position:'relative' as const },
  topbar: { position:'sticky' as const, top:0, zIndex:90, background:'rgba(14,14,14,.96)', backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)', borderBottom:'1px solid var(--bdr)', padding:'0 16px', height:52, display:'flex', alignItems:'center', gap:12 },
  logo: { fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:900, letterSpacing:3, color:'var(--sand)', flexShrink:0, cursor:'pointer' },
  feed: { flex:1, overflowY:'auto' as const, paddingBottom:72 },
  lpills: { display:'flex', gap:7, padding:'12px 16px 0', overflowX:'auto' as const },
  lp: (on:boolean) => ({ flexShrink:0, display:'flex', alignItems:'center', gap:5, padding:'6px 13px', borderRadius:20, fontSize:12, fontWeight:600, background: on ? 'var(--or)' : 'var(--s2)', border: `1px solid ${on ? 'var(--or)' : 'var(--bdr)'}`, color: on ? '#000' : 'var(--g1)', cursor:'pointer', transition:'all .15s', whiteSpace:'nowrap' as const }),
  sh: { display:'flex', alignItems:'center', justifyContent:'space-between', padding:'20px 16px 10px' },
  shTitle: { fontFamily:"'Barlow Condensed',sans-serif", fontSize:18, fontWeight:800, letterSpacing:.5, color:'var(--sand)', display:'flex', alignItems:'center', gap:6 },
  shMore: { fontSize:12, fontWeight:600, color:'var(--or)', cursor:'pointer' },
  heroCard: { margin:'12px 16px 0', borderRadius:16, overflow:'hidden', position:'relative' as const, cursor:'pointer', background:'var(--s1)', border:'1px solid var(--bdr)' },
  heroBg: (color:string) => ({ height:200, display:'flex', alignItems:'center', justifyContent:'center', position:'relative' as const, overflow:'hidden', background:`linear-gradient(135deg, ${color}, #0A0A0A)` }),
  heroOverlay: { position:'absolute' as const, bottom:0, left:0, right:0, background:'linear-gradient(transparent,rgba(0,0,0,.85))', padding:16 },
  heroScore: { fontFamily:"'Barlow Condensed',sans-serif", fontSize:42, fontWeight:900, color:'#fff', lineHeight:1, letterSpacing:1, marginBottom:4 },
  heroActions: { display:'flex', gap:8, padding:'12px 16px', borderTop:'1px solid var(--bdr)', background:'var(--s1)' },
  btnPlay: { flex:1, height:44, borderRadius:10, background:'var(--or)', color:'#000', fontSize:14, fontWeight:700, border:'none', cursor:'pointer', display:'flex', alignItems:'center', justifyContent:'center', gap:6 },
  btnOdds: { height:44, padding:'0 16px', borderRadius:10, background:'rgba(240,168,0,.12)', color:'var(--gld)', fontSize:13, fontWeight:700, border:'1px solid rgba(240,168,0,.25)', cursor:'pointer', display:'flex', alignItems:'center', gap:5 },
  mrow: { display:'flex', alignItems:'center', gap:12, padding:'14px 16px', borderBottom:'1px solid var(--bdr2)', cursor:'pointer' },
  mrowIcon: (color:string) => ({ width:42, height:42, borderRadius:10, display:'flex', alignItems:'center', justifyContent:'center', fontSize:20, flexShrink:0, background: color || 'var(--s2)' }),
  rcard: { flexShrink:0, width:160, background:'var(--s1)', borderRadius:12, border:'1px solid var(--bdr)', overflow:'hidden', cursor:'pointer' },
  rcardImg: { height:90, display:'flex', alignItems:'center', justifyContent:'center', fontSize:32, position:'relative' as const, background:'linear-gradient(135deg,#0D2137,#164E63)' },
  rankRow: { display:'flex', alignItems:'center', gap:10, padding:'11px 16px', borderBottom:'1px solid var(--bdr2)' },
  bnav: { position:'fixed' as const, bottom:0, left:'50%', transform:'translateX(-50%)', width:'100%', maxWidth:430, background:'rgba(14,14,14,.97)', backdropFilter:'blur(20px)', WebkitBackdropFilter:'blur(20px)', borderTop:'1px solid var(--bdr)', display:'flex', paddingBottom:'env(safe-area-inset-bottom, 0)', zIndex:80 },
  bnavItem: (on:boolean) => ({ flex:1, display:'flex', flexDirection:'column' as const, alignItems:'center', padding:'9px 0 7px', cursor:'pointer', gap:3, border:'none', background:'none' }),
}

function getScore(sets: Array<{a:number,b:number}> | null) {
  if (!sets || sets.length === 0) return null
  const a = sets.reduce((s,x) => s + (x.a > x.b ? 1 : 0), 0)
  const b = sets.reduce((s,x) => s + (x.b > x.a ? 1 : 0), 0)
  return { a, b, sets }
}

/* ── PLAYER SCREEN ── */
function PlayerScreen({ match, onClose, isPremium }: { match: Match & any, onClose: () => void, isPremium: boolean }) {
  const [tab, setTab] = useState('stats')
  const [progress, setProgress] = useState(25)
  const [playing, setPlaying] = useState(true)
  const [selBet, setSelBet] = useState<{[k:string]:number}>({})

  const sc = getScore(match.score_sets)
  const stats = match.match_stats?.[0]
  const odds = match.odds?.[0]
  const stream = match.streams?.[0]

  const hasRealStream = stream?.hls_playback_url

  useEffect(() => {
    if (!playing || hasRealStream) return
    const t = setInterval(() => setProgress(p => Math.min(p + 0.04, 100)), 200)
    return () => clearInterval(t)
  }, [playing, hasRealStream])

  const tabs = ['STATS','ATLETI','RANKING','BET']

  return (
    <div style={{ position:'fixed', inset:0, zIndex:200, background:'#000', display:'flex', flexDirection:'column' }}>
      {/* Header */}
      <div style={{ padding:'12px 16px', paddingTop:'max(12px,env(safe-area-inset-top))', display:'flex', alignItems:'center', gap:10, background:'linear-gradient(to bottom,rgba(0,0,0,.9),transparent)', position:'absolute', top:0, left:0, right:0, zIndex:10 }}>
        <button onClick={onClose} style={{ width:36, height:36, borderRadius:'50%', background:'rgba(255,255,255,.12)', border:'none', color:'#fff', fontSize:18, cursor:'pointer' }}>←</button>
        <div style={{ flex:1, minWidth:0 }}>
          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:14, fontWeight:700, color:'#fff', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' as const }}>{match.team_a_name} vs {match.team_b_name}</div>
          <div style={{ fontSize:10, color:'rgba(255,255,255,.4)' }}>{match.tournament} · {match.tier}</div>
        </div>
        {match.status === 'live' && <LiveBadge/>}
      </div>

      {/* Video */}
      {hasRealStream ? (
        <VideoPlayer hlsUrl={stream.hls_playback_url} isLive={match.status === 'live'} />
      ) : (
        <div style={{ width:'100%', aspectRatio:'16/9', background:'linear-gradient(135deg,#020D1A,#0A3A5A)', display:'flex', flexDirection:'column' as const, alignItems:'center', justifyContent:'center', position:'relative' as const, overflow:'hidden', flexShrink:0 }}>
          <div style={{ fontSize:80, opacity:.15, position:'absolute' }}>🏐</div>
          <div style={{ fontSize:11, color:'rgba(255,255,255,.25)', letterSpacing:2, position:'relative' }}>LIVE STREAMING — SANDR.TV</div>
          {match.status === 'live' && (
            <div style={{ position:'absolute', top:52, right:12, display:'flex', alignItems:'center', gap:5, background:'rgba(255,53,53,.15)', border:'1px solid rgba(255,53,53,.4)', borderRadius:5, padding:'4px 10px' }}>
              <span style={{ width:5, height:5, borderRadius:'50%', background:'var(--red)', animation:'bk 1s infinite' }}/>
              <span style={{ fontSize:10, fontWeight:800, color:'var(--red)', letterSpacing:.8 }}>LIVE</span>
              <style>{`@keyframes bk{0%,100%{opacity:1}50%{opacity:.25}}`}</style>
            </div>
          )}
          {sc && (
            <div style={{ position:'absolute', bottom:0, left:0, right:0, background:'linear-gradient(transparent,rgba(0,0,0,.85))', padding:'10px 14px' }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:32, fontWeight:900, color:'#fff', letterSpacing:2 }}>{sc.a} – {sc.b}</div>
              <div style={{ display:'flex', gap:5, marginTop:2 }}>
                {sc.sets.map((s,i) => (
                  <span key={i} style={{ fontSize:10, color: s.a>s.b ? 'var(--or)' : 'rgba(255,255,255,.4)', background: s.a>s.b ? 'rgba(240,78,0,.15)' : 'rgba(255,255,255,.07)', padding:'1px 6px', borderRadius:2 }}>{s.a}-{s.b}</span>
                ))}
              </div>
            </div>
          )}
          {/* Fake controls */}
          <div style={{ position:'absolute', bottom:0, left:0, right:0 }}>
            <div style={{ padding:'0 14px', marginBottom:8 }}>
              <div style={{ height:3, background:'rgba(255,255,255,.12)', borderRadius:2, cursor:'pointer', position:'relative' as const }} onClick={e => {
                const r = e.currentTarget.getBoundingClientRect()
                setProgress(((e.clientX - r.left) / r.width) * 100)
              }}>
                <div style={{ height:'100%', width:progress+'%', background:'var(--or)', borderRadius:2, transition:'width .25s' }}/>
              </div>
            </div>
            <div style={{ display:'flex', alignItems:'center', gap:14, padding:'0 14px 10px' }}>
              {['⏮','','⏭','🔊'].map((b,i) => i===1 ? (
                <button key={i} onClick={() => setPlaying(p=>!p)} style={{ background:'none', border:'none', color:'#fff', fontSize:24, cursor:'pointer', opacity:.8 }}>{playing ? '⏸' : '▶'}</button>
              ) : (
                <button key={i} style={{ background:'none', border:'none', color:'#fff', fontSize:18, cursor:'pointer', opacity:.8 }}>{b}</button>
              ))}
              <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:20, fontWeight:900, color:'#fff', letterSpacing:1, margin:'0 auto' }}>{sc ? `${sc.a} — ${sc.b}` : ''}</span>
              <button style={{ background:'none', border:'none', color:'#fff', fontSize:18, cursor:'pointer', opacity:.8 }}>⛶</button>
            </div>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div style={{ display:'flex', borderBottom:'1px solid var(--bdr)', background:'var(--s1)', overflowX:'auto' as const, flexShrink:0 }}>
        {tabs.map(t => (
          <button key={t} onClick={() => setTab(t.toLowerCase())} style={{ flex:1, minWidth:0, padding:'10px 4px', textAlign:'center', fontSize:10, fontWeight:700, letterSpacing:.5, color: tab===t.toLowerCase() ? 'var(--or)' : 'var(--g1)', border:'none', background:'none', cursor:'pointer', borderBottom: tab===t.toLowerCase() ? '2px solid var(--or)' : '2px solid transparent', whiteSpace:'nowrap' as const }}>{t}</button>
        ))}
      </div>

      {/* Tab Content */}
      <div style={{ flex:1, overflowY:'auto' as const, background:'var(--bg)', padding:16 }}>

        {tab === 'stats' && (
          <>
            {stats ? (
              <>
                <div style={{ display:'flex', justifyContent:'space-between', marginBottom:14 }}>
                  <span style={{ fontSize:12, fontWeight:700, color:'var(--or)' }}>{match.team_a_flag} {match.team_a_name}</span>
                  <span style={{ fontSize:12, fontWeight:700, color:'var(--blue)' }}>{match.team_b_flag} {match.team_b_name}</span>
                </div>
                {[
                  { label:'ACE', a:stats.team_a_aces, b:stats.team_b_aces },
                  { label:'MURI', a:stats.team_a_blocks, b:stats.team_b_blocks },
                  { label:'PUNTI ATT.', a:stats.team_a_kills, b:stats.team_b_kills },
                  { label:'ERRORI', a:stats.team_a_errors, b:stats.team_b_errors },
                ].map(s => (
                  <div key={s.label} style={{ marginBottom:14 }}>
                    <div style={{ display:'flex', justifyContent:'space-between', marginBottom:5 }}>
                      <span style={{ fontSize:13, fontWeight:700, color:'var(--or)' }}>{s.a}</span>
                      <span style={{ fontSize:11, fontWeight:600, color:'var(--g1)' }}>{s.label}</span>
                      <span style={{ fontSize:13, fontWeight:700, color:'var(--blue)' }}>{s.b}</span>
                    </div>
                    <div style={{ height:5, borderRadius:3, background:'var(--s3)', overflow:'hidden', display:'flex' }}>
                      <div style={{ flex:s.a, background:'var(--or)', transition:'flex .5s' }}/>
                      <div style={{ flex:s.b, background:'var(--blue)', transition:'flex .5s' }}/>
                    </div>
                  </div>
                ))}
              </>
            ) : (
              <div style={{ textAlign:'center', padding:40, color:'var(--g2)', fontSize:14 }}>Statistiche non disponibili per questa partita</div>
            )}
          </>
        )}

        {tab === 'atleti' && (
          <>
            {[
              { team:'a', name:match.team_a_name, flag:match.team_a_flag, rank:match.team_a_rank, color:'var(--or)' },
              { team:'b', name:match.team_b_name, flag:match.team_b_flag, rank:match.team_b_rank, color:'var(--blue)' },
            ].map((a) => (
              <div key={a.team} style={{ background:'var(--s1)', borderRadius:12, padding:14, border:'1px solid var(--bdr)', marginBottom:10 }}>
                <div style={{ display:'flex', alignItems:'center', gap:10, marginBottom:12 }}>
                  <div style={{ width:44, height:44, borderRadius:'50%', background:'var(--s3)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:22, border:'2px solid var(--bdr)', flexShrink:0 }}>{a.flag}</div>
                  <div style={{ flex:1 }}>
                    <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:17, fontWeight:800, color:'var(--sand)' }}>{a.name}</div>
                    <div style={{ fontSize:11, color:'var(--g1)', marginTop:1 }}>{a.flag} · {match.tier}</div>
                  </div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:18, fontWeight:900, color:a.color, background:'rgba(240,78,0,.1)', padding:'4px 10px', borderRadius:6 }}>#{a.rank}</div>
                </div>
                <div style={{ display:'grid', gridTemplateColumns:'repeat(3,1fr)', gap:8 }}>
                  {[['42','VITTORIE'],['8','SCONFITTE'],['84%','WIN RATE']].map(([v,l]) => (
                    <div key={l} style={{ textAlign:'center' }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:800, color:a.color }}>{v}</div>
                      <div style={{ fontSize:9, color:'var(--g1)', fontWeight:600, letterSpacing:.5 }}>{l}</div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </>
        )}

        {tab === 'ranking' && (
          <>
            <div style={{ fontSize:11, color:'var(--g1)', marginBottom:12 }}>World Ranking FIVB · fivbeach.com</div>
            {RANKINGS.map((r,i) => (
              <div key={i} style={{ display:'flex', alignItems:'center', gap:10, padding:'10px 0', borderBottom:'1px solid var(--bdr2)' }}>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:800, color:'var(--or)', width:30 }}>{r.r}</span>
                <span style={{ fontSize:18 }}>{r.flag}</span>
                <span style={{ fontSize:13, fontWeight:600, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' as const }}>{r.pair}</span>
                <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand2)' }}>{r.pts.toLocaleString()}</span>
                <span style={{ fontSize:12, width:18, color: r.tr==='▲' ? 'var(--grn)' : r.tr==='▼' ? 'var(--red)' : 'var(--g2)' }}>{r.tr}</span>
              </div>
            ))}
          </>
        )}

        {tab === 'bet' && odds && (
          <>
            <div style={{ background:'linear-gradient(135deg,rgba(240,168,0,.06),rgba(240,168,0,.02))', border:'1px solid rgba(240,168,0,.2)', borderRadius:12, padding:14, marginBottom:12 }}>
              <div style={{ display:'flex', justifyContent:'space-between', alignItems:'center', marginBottom:12 }}>
                <span style={{ fontSize:12, fontWeight:700, color:'var(--gld)', letterSpacing:.5 }}>🎲 Quote Live — Snai</span>
                <span style={{ fontSize:9, color:'var(--g2)' }}>18+</span>
              </div>
              {[
                { id:'winner', label:'Vincitore partita', a:odds.team_a_odd, b:odds.team_b_odd },
                { id:'set', label:'Handicap set (-0.5)', a:(odds.team_a_odd+0.4).toFixed(2), b:(odds.team_b_odd-0.2).toFixed(2) },
                { id:'pts', label:'Over 47.5 punti totali', a:'1.85', b:'1.90' },
              ].map(m => (
                <div key={m.id} style={{ marginBottom:12 }}>
                  <div style={{ fontSize:10, color:'var(--g1)', fontWeight:600, marginBottom:7, letterSpacing:.3 }}>{m.label}</div>
                  <div style={{ display:'flex', gap:7 }}>
                    {[{label:match.team_a_name.split('/')[0],val:m.a},{label:match.team_b_name.split('/')[0],val:m.b}].map((o,j) => (
                      <div key={j}
                        onClick={() => setSelBet(s => ({...s, [m.id]:j}))}
                        style={{ flex:1, padding:'10px 6px', borderRadius:8, background: selBet[m.id]===j ? 'rgba(240,168,0,.12)' : 'var(--s2)', border:`1px solid ${selBet[m.id]===j ? 'var(--gld)' : 'rgba(240,168,0,.15)'}`, cursor:'pointer', textAlign:'center' }}>
                        <div style={{ fontSize:9, color:'var(--g1)', marginBottom:3, fontWeight:600 }}>{o.label}</div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:800, color:'var(--gld)' }}>{typeof o.val === 'number' ? o.val.toFixed(2) : o.val}</div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
              {Object.keys(selBet).length > 0 && (
                <button onClick={() => window.open('https://snai.it','_blank')} style={{ width:'100%', height:40, borderRadius:8, background:'var(--gld)', color:'#000', fontSize:13, fontWeight:700, border:'none', cursor:'pointer' }}>Scommetti su Snai →</button>
              )}
              <div style={{ fontSize:9, color:'var(--g2)', textAlign:'center', marginTop:8, lineHeight:1.5 }}>18+ · Il gioco d'azzardo può causare dipendenza patologica.<br/>Gioca responsabile · probabilità di vincita secondo LEPS</div>
            </div>
          </>
        )}

        {tab === 'bet' && !odds && (
          <div style={{ textAlign:'center', padding:40, color:'var(--g2)', fontSize:14 }}>Quote non disponibili</div>
        )}
      </div>
    </div>
  )
}

/* ── PAYWALL ── */
function Paywall({ onClose, onSubscribe }: { onClose: () => void, onSubscribe: () => void }) {
  const [sel, setSel] = useState('monthly')
  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, zIndex:300, background:'rgba(0,0,0,.8)', backdropFilter:'blur(8px)', display:'flex', alignItems:'flex-end' }}>
      <div onClick={e => e.stopPropagation()} style={{ width:'100%', background:'var(--s1)', borderRadius:'20px 20px 0 0', borderTop:'1px solid var(--bdr)', padding:'20px 20px max(20px,env(safe-area-inset-bottom))', animation:'su .25s ease' }}>
        <style>{`@keyframes su{from{transform:translateY(40px);opacity:0}to{transform:translateY(0);opacity:1}}`}</style>
        <div style={{ width:36, height:4, background:'var(--s3)', borderRadius:2, margin:'0 auto 18px' }}/>
        <div style={{ fontSize:10, fontWeight:700, color:'var(--or)', letterSpacing:2, textTransform:'uppercase', marginBottom:6 }}>Contenuto Premium</div>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:30, fontWeight:900, marginBottom:6 }}>Sblocca SANDR</div>
        <div style={{ fontSize:13, color:'var(--g1)', marginBottom:20, lineHeight:1.5 }}>Tutte le partite live, repliche HD, statistiche in tempo reale. Disdici quando vuoi.</div>
        <div style={{ display:'flex', gap:10, marginBottom:18 }}>
          {[
            { id:'monthly', name:'Monthly', price:'4,99', per:'/mese', feats:['Partite live','Archivio repliche','Stats live','Betting','Tutti i circuiti'] },
            { id:'annual', name:'Annual', price:'39,99', per:'/anno', feats:['Tutto di Monthly','Risparmia 33%','Accesso anticipato','Download offline','Notifiche priority'] },
          ].map(p => (
            <div key={p.id} onClick={() => setSel(p.id)} style={{ flex:1, background:'var(--s2)', borderRadius:12, padding:14, border:`2px solid ${sel===p.id ? 'var(--or)' : 'var(--bdr)'}`, cursor:'pointer' }}>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:16, fontWeight:800, marginBottom:4 }}>{p.name}</div>
              <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:28, fontWeight:900, color:'var(--or)', lineHeight:1 }}>€{p.price}</div>
              <div style={{ fontSize:11, color:'var(--g1)', marginBottom:10 }}>{p.per}</div>
              {p.feats.map((f,i) => (
                <div key={i} style={{ fontSize:11, color:'var(--g1)', display:'flex', gap:5, marginBottom:3 }}>
                  <span style={{ color:'var(--grn)' }}>✓</span><span>{f}</span>
                </div>
              ))}
            </div>
          ))}
        </div>
        <button onClick={() => { onSubscribe(); onClose() }} style={{ width:'100%', height:50, borderRadius:12, background:'var(--or)', color:'#000', fontSize:16, fontWeight:700, border:'none', cursor:'pointer' }}>
          Inizia con €{sel==='monthly'?'4,99/mese':'39,99/anno'}
        </button>
        <div style={{ fontSize:10, color:'var(--g2)', textAlign:'center', marginTop:10 }}>Stripe Checkout sicuro · Nessun vincolo · Cancella subito</div>
      </div>
    </div>
  )
}

/* ── AUTH MODAL ── */
function AuthModal({ onClose, onLogin }: { onClose: () => void, onLogin: (profile: Profile) => void }) {
  const [mode, setMode] = useState<'login'|'signup'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const inputStyle = { width:'100%', padding:'12px 14px', borderRadius:8, background:'var(--s3)', border:'1px solid var(--bdr)', color:'var(--sand)', fontSize:14, outline:'none', marginBottom:10, fontFamily:"'Barlow',sans-serif" }

  const submit = async () => {
    setLoading(true); setError('')
    if (mode === 'signup') {
      const res = await fetch('/api/auth/signup', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({ email, password, name }) })
      const data = await res.json()
      if (data.error) { setError(data.error); setLoading(false); return }
    }
    const { error: err } = await supabase.auth.signInWithPassword({ email, password })
    if (err) { setError(err.message); setLoading(false); return }
    const { data: prof } = await supabase.from('profiles').select('*').eq('id', (await supabase.auth.getUser()).data.user?.id || '').single()
    if (prof) onLogin(prof as Profile)
    onClose()
    setLoading(false)
  }

  return (
    <div onClick={onClose} style={{ position:'fixed', inset:0, zIndex:300, background:'rgba(0,0,0,.8)', backdropFilter:'blur(8px)', display:'flex', alignItems:'flex-end' }}>
      <div onClick={e => e.stopPropagation()} style={{ width:'100%', background:'var(--s1)', borderRadius:'20px 20px 0 0', borderTop:'1px solid var(--bdr)', padding:'20px 20px max(20px,env(safe-area-inset-bottom))', animation:'su .25s ease' }}>
        <div style={{ width:36, height:4, background:'var(--s3)', borderRadius:2, margin:'0 auto 18px' }}/>
        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:28, fontWeight:900, marginBottom:20 }}>{mode === 'login' ? 'Accedi' : 'Registrati'}</div>
        {mode === 'signup' && <input placeholder="Il tuo nome" value={name} onChange={e => setName(e.target.value)} style={inputStyle}/>}
        <input type="email" placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={inputStyle}/>
        <input type="password" placeholder="Password" value={password} onChange={e => setPassword(e.target.value)} style={inputStyle}/>
        {error && <div style={{ fontSize:12, color:'var(--red)', marginBottom:10 }}>{error}</div>}
        <button onClick={submit} disabled={loading} style={{ width:'100%', height:50, borderRadius:12, background:'var(--or)', color:'#000', fontSize:16, fontWeight:700, border:'none', cursor:'pointer', marginBottom:12 }}>
          {loading ? '...' : mode === 'login' ? 'Accedi' : 'Crea account'}
        </button>
        <div style={{ textAlign:'center', fontSize:13, color:'var(--g1)' }}>
          {mode === 'login' ? 'Non hai un account? ' : 'Hai già un account? '}
          <span onClick={() => setMode(m => m === 'login' ? 'signup' : 'login')} style={{ color:'var(--or)', cursor:'pointer', fontWeight:600 }}>
            {mode === 'login' ? 'Registrati' : 'Accedi'}
          </span>
        </div>
      </div>
    </div>
  )
}

/* ── MAIN APP ── */
export default function Home() {
  const [tab, setTab] = useState('home')
  const [league, setLeague] = useState('all')
  const [matches, setMatches] = useState<(Match & any)[]>([])
  const [videos, setVideos] = useState<(Video & any)[]>([])
  const [loading, setLoading] = useState(true)
  const [watching, setWatch] = useState<(Match & any) | null>(null)
  const [showPW, setShowPW] = useState(false)
  const [showAuth, setShowAuth] = useState(false)
  const [profile, setProfile] = useState<Profile | null>(null)
  const [toast, setToast] = useState('')

  const showToast = (msg: string) => { setToast(msg); setTimeout(() => setToast(''), 2200) }

  useEffect(() => {
    // Check session
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session?.user) {
        const { data } = await supabase.from('profiles').select('*').eq('id', session.user.id).single()
        setProfile(data as Profile)
      }
    })
  }, [])

  useEffect(() => {
    const fetchMatches = async () => {
      const res = await fetch(`/api/matches${league !== 'all' ? `?league=${league}` : ''}`)
      const data = await res.json()
      setMatches(Array.isArray(data) ? data : [])
      setLoading(false)
    }
    fetchMatches()

    // Realtime
    const channel = supabase.channel('rt-matches')
      .on('postgres_changes', { event:'*', schema:'public', table:'matches' }, fetchMatches)
      .on('postgres_changes', { event:'*', schema:'public', table:'match_stats' }, fetchMatches)
      .subscribe()
    return () => { supabase.removeChannel(channel) }
  }, [league])

  useEffect(() => {
    if (tab === 'repliche') {
      fetch(`/api/videos${league !== 'all' ? `?league=${league}` : ''}`)
        .then(r => r.json()).then(data => setVideos(Array.isArray(data) ? data : []))
    }
  }, [tab, league])

  const tryWatch = (m: Match & any) => {
    if (!m.is_free && profile?.plan === 'free') setShowPW(true)
    else setWatch(m)
  }

  const liveMatches = matches.filter(m => m.status === 'live')
  const upcoming = matches.filter(m => m.status === 'scheduled')

  const NAV = [
    { id:'home', icon:'🏠', label:'Home' },
    { id:'live', icon:'🔴', label:'Live' },
    { id:'repliche', icon:'▶', label:'Repliche' },
    { id:'ranking', icon:'🏆', label:'Ranking' },
    { id:'profilo', icon:'👤', label:'Profilo' },
  ]

  return (
    <>
      {toast && <div style={{ position:'fixed', top:60, left:'50%', transform:'translateX(-50%)', background:'var(--s2)', color:'var(--sand)', padding:'9px 18px', borderRadius:20, fontSize:13, fontWeight:600, border:'1px solid var(--bdr)', zIndex:500, boxShadow:'0 4px 20px rgba(0,0,0,.5)', whiteSpace:'nowrap' as const }}>{toast}</div>}
      {watching && <PlayerScreen match={watching} onClose={() => setWatch(null)} isPremium={profile?.plan !== 'free'} />}
      {showPW && <Paywall onClose={() => setShowPW(false)} onSubscribe={async () => {
        if (!profile) { setShowAuth(true); return }
        await supabase.from('profiles').update({ plan: 'premium' }).eq('id', profile.id)
        setProfile(p => p ? {...p, plan:'premium'} : null)
        showToast('✅ Piano Premium attivato!')
      }}/>}
      {showAuth && <AuthModal onClose={() => setShowAuth(false)} onLogin={p => setProfile(p)}/>}

      <div style={S.shell}>
        {/* TOPBAR */}
        <div style={S.topbar}>
          <div style={S.logo} onClick={() => setTab('home')}>S<span style={{color:'var(--or)'}}>A</span>NDR</div>
          <div style={{ display:'flex', alignItems:'center', gap:8, marginLeft:'auto' }}>
            <div onClick={() => profile ? null : setShowAuth(true)} style={{ padding:'3px 10px', borderRadius:20, fontSize:10, fontWeight:700, letterSpacing:.5, cursor:'pointer', background: profile?.plan === 'premium' ? 'rgba(240,78,0,.15)' : 'var(--s3)', color: profile?.plan === 'premium' ? 'var(--or)' : 'var(--g1)', border: profile?.plan === 'premium' ? '1px solid rgba(240,78,0,.3)' : '1px solid transparent' }}>
              {profile ? (profile.plan === 'premium' ? '★ PREMIUM' : 'FREE') : 'LOGIN'}
            </div>
            <div onClick={() => showToast('🔔 Notifiche')} style={{ width:32, height:32, borderRadius:'50%', background:'var(--s2)', border:'1px solid var(--bdr)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:14, cursor:'pointer' }}>🔔</div>
          </div>
        </div>

        <div style={S.feed}>
          {/* LEAGUE FILTER */}
          {['home','live','repliche'].includes(tab) && (
            <div style={S.lpills}>
              {LEAGUES.map(l => (
                <div key={l.id} style={S.lp(league === l.id)} onClick={() => setLeague(l.id)}>
                  <span>{l.flag}</span><span>{l.label}</span>
                </div>
              ))}
            </div>
          )}

          {/* ── HOME ── */}
          {tab === 'home' && (
            <>
              {/* First-run seed button */}
              {!loading && matches.length === 0 && (
                <div style={{ margin:'20px 16px', padding:16, background:'var(--s1)', borderRadius:12, border:'1px solid var(--bdr)', textAlign:'center' }}>
                  <div style={{ fontSize:14, color:'var(--g1)', marginBottom:12 }}>Nessuna partita nel database.<br/>Clicca per popolare con dati demo.</div>
                  <button onClick={async () => {
                    const res = await fetch('/api/admin/seed', { method:'POST' })
                    const data = await res.json()
                    if (data.ok) { showToast(`✅ ${data.matches} partite aggiunte!`); setTimeout(() => window.location.reload(), 1000) }
                    else showToast('❌ ' + (data.error || 'Errore'))
                  }} style={{ padding:'10px 24px', borderRadius:8, background:'var(--or)', color:'#000', fontWeight:700, border:'none', cursor:'pointer', fontSize:14 }}>
                    Carica dati demo →
                  </button>
                </div>
              )}

              {/* Live Hero */}
              {liveMatches.length > 0 && (
                <>
                  <div style={S.sh}>
                    <div style={S.shTitle}><LiveBadge/> Live ora</div>
                    <span style={S.shMore} onClick={() => setTab('live')}>Vedi tutto →</span>
                  </div>
                  <div style={S.heroCard} onClick={() => tryWatch(liveMatches[0])}>
                    <div style={S.heroBg(liveMatches[0].color || '#0D3B6E')}>
                      <div style={{ fontSize:64, opacity:.15, position:'absolute' }}>🏐</div>
                      <div style={S.heroOverlay}>
                        <div style={{ display:'flex', gap:6, marginBottom:8 }}>
                          <LiveBadge/>
                          {liveMatches[0].is_free ? <FreeTag/> : <PremTag/>}
                        </div>
                        {(() => { const sc = getScore(liveMatches[0].score_sets); return sc ? (
                          <>
                            <div style={S.heroScore}>{sc.a} — {sc.b}</div>
                            <div style={{ display:'flex', gap:5, marginBottom:4 }}>
                              {sc.sets.map((s,i) => <span key={i} style={{ fontSize:10, color: s.a>s.b?'var(--or)':'rgba(255,255,255,.4)', background: s.a>s.b?'rgba(240,78,0,.15)':'rgba(255,255,255,.07)', padding:'1px 6px', borderRadius:2 }}>{s.a}-{s.b}</span>)}
                            </div>
                          </>
                        ) : null })()}
                        <div style={{ fontSize:13, fontWeight:600, color:'rgba(255,255,255,.8)' }}>
                          {liveMatches[0].team_a_flag} {liveMatches[0].team_a_name} · {liveMatches[0].team_b_flag} {liveMatches[0].team_b_name}
                        </div>
                        <div style={{ fontSize:11, color:'rgba(255,255,255,.45)', marginTop:2 }}>{liveMatches[0].tournament} · {liveMatches[0].tier}</div>
                      </div>
                    </div>
                    <div style={S.heroActions} onClick={e => e.stopPropagation()}>
                      <button style={S.btnPlay} onClick={() => tryWatch(liveMatches[0])}>▶ Guarda Live</button>
                      {liveMatches[0].odds?.[0] && (
                        <div style={S.btnOdds}>🎲 {liveMatches[0].odds[0].team_a_odd?.toFixed(2)} / {liveMatches[0].odds[0].team_b_odd?.toFixed(2)}</div>
                      )}
                    </div>
                  </div>
                  {liveMatches.slice(1).map(m => {
                    const sc = getScore(m.score_sets)
                    return (
                      <div key={m.id} style={S.mrow} onClick={() => tryWatch(m)}>
                        <div style={S.mrowIcon(m.color || 'var(--s2)')}>🏐</div>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:9, fontWeight:700, color:'var(--or)', letterSpacing:.8, textTransform:'uppercase' as const, marginBottom:3 }}>{m.league.toUpperCase()} · {m.tier}</div>
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand)', whiteSpace:'nowrap' as const, overflow:'hidden', textOverflow:'ellipsis' }}>{m.team_a_flag} {m.team_a_name} vs {m.team_b_flag} {m.team_b_name}</div>
                          <div style={{ fontSize:11, color:'var(--g1)' }}>{m.tournament}</div>
                        </div>
                        <div style={{ textAlign:'right' as const, flexShrink:0 }}>
                          {sc && <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:20, fontWeight:800 }}>{sc.a}–{sc.b}</div>}
                          <LiveBadge/>
                        </div>
                      </div>
                    )
                  })}
                </>
              )}

              {/* Upcoming */}
              {upcoming.length > 0 && (
                <>
                  <div style={S.sh}>
                    <div style={S.shTitle}>📅 In Programma</div>
                    <span style={S.shMore} onClick={() => setTab('live')}>Calendario →</span>
                  </div>
                  {upcoming.map(m => (
                    <div key={m.id} style={{ ...S.mrow, cursor:'default' }}>
                      <div style={S.mrowIcon('var(--s2)')}>🏐</div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:9, fontWeight:700, color:'var(--or)', letterSpacing:.8, textTransform:'uppercase' as const, marginBottom:3 }}>{m.league.toUpperCase()} · {m.tier}</div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand)', whiteSpace:'nowrap' as const, overflow:'hidden', textOverflow:'ellipsis' }}>{m.team_a_flag} {m.team_a_name} vs {m.team_b_flag} {m.team_b_name}</div>
                        <div style={{ fontSize:11, color:'var(--g1)' }}>{m.tournament}</div>
                      </div>
                      <div style={{ textAlign:'right' as const, flexShrink:0, display:'flex', flexDirection:'column' as const, alignItems:'flex-end', gap:4 }}>
                        <div style={{ fontSize:11, color:'var(--g1)' }}>{new Date(m.scheduled_at).toLocaleString('it-IT', { weekday:'short', day:'numeric', month:'short', hour:'2-digit', minute:'2-digit' })}</div>
                        {m.odds?.[0] && <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:13, color:'var(--gld)', fontWeight:700 }}>🎲 {m.odds[0].team_a_odd?.toFixed(2)}/{m.odds[0].team_b_odd?.toFixed(2)}</div>}
                        <button onClick={() => showToast('🔔 Reminder impostato!')} style={{ padding:'4px 10px', borderRadius:6, fontSize:10, fontWeight:700, background:'rgba(240,78,0,.1)', color:'var(--or)', border:'1px solid rgba(240,78,0,.25)', cursor:'pointer' }}>🔔</button>
                      </div>
                    </div>
                  ))}
                </>
              )}

              {/* Ranking preview */}
              <div style={S.sh}>
                <div style={S.shTitle}>🏆 World Ranking</div>
                <span style={S.shMore} onClick={() => setTab('ranking')}>Completo →</span>
              </div>
              <div style={{ padding:'0 16px' }}>
                {RANKINGS.slice(0,5).map((r,i) => (
                  <div key={i} style={S.rankRow}>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:800, color:'var(--or)', width:30, textAlign:'center' as const }}>{r.r}</span>
                    <span style={{ fontSize:18 }}>{r.flag}</span>
                    <span style={{ fontSize:13, fontWeight:600, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' as const }}>{r.pair}</span>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand2)' }}>{r.pts.toLocaleString()}</span>
                    <span style={{ fontSize:12, width:18, textAlign:'center' as const, color: r.tr==='▲'?'var(--grn)':r.tr==='▼'?'var(--red)':'var(--g2)' }}>{r.tr}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ── LIVE TAB ── */}
          {tab === 'live' && (
            <>
              {liveMatches.length > 0 && (
                <>
                  <div style={S.sh}><div style={S.shTitle}><LiveBadge/> Ora in diretta</div></div>
                  {liveMatches.map(m => {
                    const sc = getScore(m.score_sets)
                    return (
                      <div key={m.id} style={{ ...S.mrow, padding:16, alignItems:'flex-start' }} onClick={() => tryWatch(m)}>
                        <div style={{ ...S.mrowIcon(m.color || 'var(--s2)'), width:48, height:48 }}>🏐</div>
                        <div style={{ flex:1, minWidth:0 }}>
                          <div style={{ fontSize:9, fontWeight:700, color:'var(--or)', letterSpacing:.8, textTransform:'uppercase' as const, marginBottom:3 }}>{m.league.toUpperCase()} · {m.tier}</div>
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand)', marginBottom:2 }}>{m.team_a_flag} {m.team_a_name}</div>
                          <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand)', marginBottom:4 }}>{m.team_b_flag} {m.team_b_name}</div>
                          <div style={{ fontSize:11, color:'var(--g1)' }}>{m.tournament} · {m.is_free ? '🟢 Free' : '🔒 Premium'}</div>
                        </div>
                        <div style={{ display:'flex', flexDirection:'column' as const, alignItems:'flex-end', gap:4, flexShrink:0 }}>
                          {sc && <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:26, fontWeight:900 }}>{sc.a} – {sc.b}</div>}
                          {sc && <div style={{ fontSize:10, color:'var(--g1)' }}>{sc.sets.map(s=>`${s.a}-${s.b}`).join(' / ')}</div>}
                          <LiveBadge/>
                          {m.odds?.[0] && <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:13, color:'var(--gld)', fontWeight:700 }}>🎲 {m.odds[0].team_a_odd?.toFixed(2)}/{m.odds[0].team_b_odd?.toFixed(2)}</div>}
                        </div>
                      </div>
                    )
                  })}
                </>
              )}
              {upcoming.length > 0 && (
                <>
                  <div style={S.sh}><div style={S.shTitle}>📅 Prossime partite</div></div>
                  {upcoming.map(m => (
                    <div key={m.id} style={S.mrow}>
                      <div style={S.mrowIcon('var(--s2)')}>🏐</div>
                      <div style={{ flex:1, minWidth:0 }}>
                        <div style={{ fontSize:9, fontWeight:700, color:'var(--or)', letterSpacing:.8, textTransform:'uppercase' as const, marginBottom:3 }}>{m.league.toUpperCase()} · {m.tier}</div>
                        <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand)', whiteSpace:'nowrap' as const, overflow:'hidden', textOverflow:'ellipsis' }}>{m.team_a_flag} {m.team_a_name} vs {m.team_b_flag} {m.team_b_name}</div>
                        <div style={{ fontSize:11, color:'var(--g1)' }}>{m.tournament}</div>
                      </div>
                      <div style={{ textAlign:'right' as const, flexShrink:0 }}>
                        <div style={{ fontSize:11, color:'var(--g1)', marginBottom:4 }}>{new Date(m.scheduled_at).toLocaleString('it-IT', { weekday:'short', hour:'2-digit', minute:'2-digit' })}</div>
                        {m.odds?.[0] && <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:13, color:'var(--gld)' }}>🎲 {m.odds[0].team_a_odd?.toFixed(2)}/{m.odds[0].team_b_odd?.toFixed(2)}</div>}
                        <button onClick={() => showToast('🔔 Reminder!')} style={{ marginTop:4, padding:'5px 12px', borderRadius:6, fontSize:10, fontWeight:700, background:'rgba(240,78,0,.1)', color:'var(--or)', border:'1px solid rgba(240,78,0,.25)', cursor:'pointer' }}>🔔 Ricordami</button>
                      </div>
                    </div>
                  ))}
                </>
              )}
              {liveMatches.length === 0 && upcoming.length === 0 && !loading && (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--g2)' }}>
                  <div style={{ fontSize:48, marginBottom:12 }}>📡</div>
                  <div>Nessuna partita disponibile per questo filtro</div>
                </div>
              )}
            </>
          )}

          {/* ── REPLICHE ── */}
          {tab === 'repliche' && (
            <>
              <div style={S.sh}><div style={S.shTitle}>🎞 Archivio Repliche</div></div>
              {videos.length === 0 ? (
                <div style={{ textAlign:'center', padding:'60px 20px', color:'var(--g2)' }}>
                  <div style={{ fontSize:48, marginBottom:12 }}>📼</div>
                  <div>Nessuna replica disponibile</div>
                </div>
              ) : videos.map((v: any) => (
                <div key={v.id} style={{ display:'flex', gap:12, padding:'14px 16px', borderBottom:'1px solid var(--bdr2)', cursor:'pointer' }}
                  onClick={() => { if (!v.is_free && profile?.plan === 'free') setShowPW(true); else showToast('▶ Caricamento...') }}>
                  <div style={{ width:100, height:64, borderRadius:8, flexShrink:0, background:'linear-gradient(135deg,#0D2137,#164E63)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:24, position:'relative' as const, overflow:'hidden' }}>
                    🏐
                    {!v.is_free && profile?.plan === 'free' && <div style={{ position:'absolute', inset:0, background:'rgba(0,0,0,.55)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:18 }}>🔒</div>}
                    {v.duration_seconds && <div style={{ position:'absolute', bottom:4, right:5, background:'rgba(0,0,0,.7)', color:'#fff', fontSize:9, fontWeight:700, padding:'1px 5px', borderRadius:2 }}>{Math.floor(v.duration_seconds/60)}m</div>}
                  </div>
                  <div style={{ flex:1, minWidth:0 }}>
                    <div style={{ fontSize:9, fontWeight:700, color:'var(--or)', letterSpacing:.8, textTransform:'uppercase' as const, marginBottom:3 }}>{v.match?.league || 'SANDR'} · {new Date(v.published_at).toLocaleDateString('it-IT')}</div>
                    <div style={{ fontSize:13, fontWeight:600, color:'var(--sand)', marginBottom:3, lineHeight:1.3 }}>{v.match?.team_a_name || 'Partita'} vs {v.match?.team_b_name || ''}</div>
                    <div style={{ fontSize:11, color:'var(--g1)', marginBottom:4 }}>{v.match?.tournament || ''}</div>
                    <div style={{ display:'flex', gap:10, alignItems:'center' }}>
                      <span style={{ fontSize:11, color:'var(--g1)' }}>👁 {v.views_count || 0}</span>
                      <span style={{ fontSize:10, fontWeight:700, color: v.is_free ? 'var(--grn)' : 'var(--or)' }}>{v.is_free ? 'FREE' : '★ PREMIUM'}</span>
                    </div>
                  </div>
                </div>
              ))}
            </>
          )}

          {/* ── RANKING ── */}
          {tab === 'ranking' && (
            <>
              <div style={S.sh}><div style={S.shTitle}>🏆 World Ranking FIVB</div></div>
              <div style={{ padding:'0 16px 4px', fontSize:11, color:'var(--g1)' }}>Powered by fivbeach.com · FIVB VIS</div>
              <div style={{ padding:'8px 16px 0' }}>
                {RANKINGS.map((r,i) => (
                  <div key={i} style={S.rankRow}>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:22, fontWeight:800, color:'var(--or)', width:30, textAlign:'center' as const }}>{r.r}</span>
                    <span style={{ fontSize:18 }}>{r.flag}</span>
                    <span style={{ fontSize:13, fontWeight:600, flex:1, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' as const }}>{r.pair}</span>
                    <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:15, fontWeight:700, color:'var(--sand2)' }}>{r.pts.toLocaleString()}</span>
                    <span style={{ fontSize:12, width:18, textAlign:'center' as const, color: r.tr==='▲'?'var(--grn)':r.tr==='▼'?'var(--red)':'var(--g2)' }}>{r.tr}</span>
                  </div>
                ))}
              </div>
            </>
          )}

          {/* ── PROFILO ── */}
          {tab === 'profilo' && (
            <div style={{ padding:'24px 16px' }}>
              {profile ? (
                <>
                  <div style={{ background:'var(--s1)', borderRadius:16, padding:20, border:'1px solid var(--bdr)', marginBottom:16, display:'flex', alignItems:'center', gap:14 }}>
                    <div style={{ width:56, height:56, borderRadius:'50%', background:'var(--s3)', display:'flex', alignItems:'center', justifyContent:'center', fontSize:26 }}>👤</div>
                    <div style={{ flex:1 }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:20, fontWeight:800 }}>{profile.name || 'Utente'}</div>
                      <div style={{ fontSize:12, color:'var(--g1)', marginTop:2 }}>{profile.email}</div>
                    </div>
                    <div style={{ padding:'6px 14px', borderRadius:20, fontSize:11, fontWeight:700, background: profile.plan==='premium'?'rgba(240,78,0,.15)':'var(--s3)', color: profile.plan==='premium'?'var(--or)':'var(--g1)' }}>
                      {profile.plan==='premium'?'★ PREMIUM':'FREE'}
                    </div>
                  </div>
                  {profile.plan === 'free' && (
                    <div style={{ background:'rgba(240,78,0,.08)', borderRadius:12, padding:16, border:'1px solid rgba(240,78,0,.2)', marginBottom:16 }}>
                      <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:18, fontWeight:800, marginBottom:4 }}>Passa a Premium</div>
                      <div style={{ fontSize:13, color:'var(--sand2)', marginBottom:12, lineHeight:1.5 }}>Tutte le partite live, repliche HD e statistiche in tempo reale. Solo €4,99/mese.</div>
                      <button onClick={() => setShowPW(true)} style={{ width:'100%', height:44, borderRadius:10, background:'var(--or)', color:'#000', fontSize:15, fontWeight:700, border:'none', cursor:'pointer' }}>Abbonati ora →</button>
                    </div>
                  )}
                  {[{l:'Piano attivo',v:profile.plan==='premium'?'★ Premium':'Free'},{l:'Account creato',v:new Date(profile.created_at).toLocaleDateString('it-IT')}].map((s,i) => (
                    <div key={i} style={{ display:'flex', justifyContent:'space-between', alignItems:'center', padding:'14px 0', borderBottom:'1px solid var(--bdr2)' }}>
                      <span style={{ fontSize:14, color:'var(--sand2)' }}>{s.l}</span>
                      <span style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:18, fontWeight:700, color:'var(--or)' }}>{s.v}</span>
                    </div>
                  ))}
                  <button onClick={async () => { await supabase.auth.signOut(); setProfile(null); showToast('👋 Disconnesso') }} style={{ width:'100%', marginTop:20, padding:14, borderRadius:10, background:'var(--s2)', color:'var(--g1)', border:'1px solid var(--bdr)', fontSize:14, fontWeight:600, cursor:'pointer' }}>Disconnetti</button>
                </>
              ) : (
                <div style={{ textAlign:'center', padding:'60px 20px' }}>
                  <div style={{ fontSize:48, marginBottom:16 }}>👤</div>
                  <div style={{ fontFamily:"'Barlow Condensed',sans-serif", fontSize:24, fontWeight:800, marginBottom:8 }}>Accedi a SANDR</div>
                  <div style={{ fontSize:14, color:'var(--g1)', marginBottom:24 }}>Per seguire le tue partite, gestire il piano e accedere ai contenuti premium.</div>
                  <button onClick={() => setShowAuth(true)} style={{ padding:'13px 32px', borderRadius:10, background:'var(--or)', color:'#000', fontSize:15, fontWeight:700, border:'none', cursor:'pointer' }}>Accedi / Registrati</button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* BOTTOM NAV */}
        <div style={S.bnav}>
          {NAV.map(n => (
            <button key={n.id} style={S.bnavItem(tab===n.id)} onClick={() => setTab(n.id)}>
              <span style={{ fontSize:19, filter: tab===n.id ? 'drop-shadow(0 0 5px var(--or))' : 'none' }}>{n.icon}</span>
              <span style={{ fontSize:9, fontWeight:600, letterSpacing:.2, color: tab===n.id ? 'var(--or)' : 'var(--g2)' }}>{n.label}</span>
            </button>
          ))}
        </div>
      </div>
    </>
  )
}
