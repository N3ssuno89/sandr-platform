import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'SANDR — Sand Arena',
  description: 'La piattaforma streaming per il beach volley e gli sport di spiaggia',
  manifest: '/manifest.json',
  themeColor: '#0E0E0E',
  viewport: 'width=device-width, initial-scale=1, viewport-fit=cover',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="it">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body>{children}</body>
    </html>
  )
}
