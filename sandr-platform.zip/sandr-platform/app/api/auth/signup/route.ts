import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { sendWelcomeEmail } from '@/lib/resend'

export async function POST(req: Request) {
  const { email, password, name } = await req.json()
  const admin = supabaseAdmin()
  const { data, error } = await admin.auth.admin.createUser({
    email, password,
    user_metadata: { name },
    email_confirm: false,
  })
  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  await admin.from('profiles').update({ name }).eq('id', data.user.id)
  await sendWelcomeEmail(email, name || email.split('@')[0])
  return NextResponse.json({ user: data.user })
}
