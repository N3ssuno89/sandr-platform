import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const league = searchParams.get('league')

  const admin = supabaseAdmin()
  let query = admin
    .from('videos')
    .select('*, match:matches(league,tier,tournament,team_a_name,team_b_name,team_a_flag,team_b_flag)')
    .eq('type', 'replay')
    .order('published_at', { ascending: false })
    .limit(20)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  const filtered = league && league !== 'all'
    ? data.filter((v: any) => v.match?.league === league)
    : data

  return NextResponse.json(filtered)
}
