import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url)
  const league = searchParams.get('league')
  const status = searchParams.get('status')

  const admin = supabaseAdmin()
  let query = admin
    .from('matches')
    .select('*, streams(*), match_stats(*), odds(*)')
    .order('scheduled_at', { ascending: true })

  if (league && league !== 'all') query = query.eq('league', league)
  if (status) query = query.eq('status', status)

  const { data, error } = await query
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}

export async function POST(req: Request) {
  const body = await req.json()
  const admin = supabaseAdmin()
  const { data, error } = await admin.from('matches').insert(body).select().single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}
