import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function POST() {
  const admin = supabaseAdmin()

  const matches = [
    {
      league: 'bpt', tier: 'Elite 16', tournament: 'BPT Elite — Ostrava',
      team_a_name: 'Åhman / Hellvig', team_a_flag: '🇸🇪', team_a_rank: 1,
      team_b_name: 'Mol / Sørum', team_b_flag: '🇳🇴', team_b_rank: 2,
      scheduled_at: new Date().toISOString(), status: 'live',
      score_sets: [{a:21,b:19},{a:18,b:21},{a:8,b:6}], set_score: '2-1',
      is_free: true, is_ppv: false, color: '#0D3B6E',
    },
    {
      league: 'aibvc', tier: 'Nazionale', tournament: 'AIBVC — Roma',
      team_a_name: 'Rossi / Bianchi', team_a_flag: '🇮🇹', team_a_rank: 5,
      team_b_name: 'Verdi / Neri', team_b_flag: '🇮🇹', team_b_rank: 8,
      scheduled_at: new Date().toISOString(), status: 'live',
      score_sets: [{a:21,b:17},{a:19,b:21},{a:5,b:3}], set_score: '2-1',
      is_free: true, is_ppv: false, color: '#1A2A0D',
    },
    {
      league: 'bpt', tier: 'Challenge', tournament: 'BPT Challenge — Xiamen',
      team_a_name: 'Boermans / De Groot', team_a_flag: '🇳🇱', team_a_rank: 5,
      team_b_name: 'Ehlers / Wickler', team_b_flag: '🇩🇪', team_b_rank: 9,
      scheduled_at: new Date(Date.now() + 3600000).toISOString(), status: 'scheduled',
      is_free: false, is_ppv: false, color: '#0D2137',
    },
    {
      league: 'fipav', tier: 'Serie A', tournament: 'FIPAV Serie A — Caorle',
      team_a_name: 'Cottafava / Nicolai', team_a_flag: '🇮🇹', team_a_rank: 3,
      team_b_name: 'Carambula / Ranghieri', team_b_flag: '🇮🇹', team_b_rank: 7,
      scheduled_at: new Date(Date.now() + 86400000).toISOString(), status: 'scheduled',
      is_free: false, is_ppv: false, color: '#1A1A0D',
    },
    {
      league: 'avp', tier: 'Pro Tour', tournament: 'AVP Chicago Open',
      team_a_name: 'Budinger / Evans', team_a_flag: '🇺🇸', team_a_rank: 17,
      team_b_name: 'Partain / Benesh', team_b_flag: '🇺🇸', team_b_rank: 11,
      scheduled_at: new Date(Date.now() + 172800000).toISOString(), status: 'scheduled',
      is_free: true, is_ppv: false, color: '#0D1A2A',
    },
    {
      league: 'ffvb', tier: 'Championnat', tournament: 'Ligue Française — Nice',
      team_a_name: 'Bassereau / Ayé', team_a_flag: '🇫🇷', team_a_rank: 8,
      team_b_name: 'Gauthier-Rat / Krou', team_b_flag: '🇫🇷', team_b_rank: 12,
      scheduled_at: new Date(Date.now() + 259200000).toISOString(), status: 'scheduled',
      is_free: false, is_ppv: false, color: '#0D1A37',
    },
    {
      league: 'rfevb', tier: 'Liga', tournament: 'Liga Española — Barcelona',
      team_a_name: 'Herrera / Gavira', team_a_flag: '🇪🇸', team_a_rank: 14,
      team_b_name: 'Huerta / Huerta', team_b_flag: '🇪🇸', team_b_rank: 19,
      scheduled_at: new Date(Date.now() + 345600000).toISOString(), status: 'scheduled',
      is_free: true, is_ppv: false, color: '#2A0D0D',
    },
  ]

  const { data: insertedMatches, error: matchError } = await admin
    .from('matches').insert(matches).select()

  if (matchError) return NextResponse.json({ error: matchError.message }, { status: 500 })

  // Aggiungi stats per le partite live
  const liveMatches = insertedMatches.filter((m: any) => m.status === 'live')
  const statsData = liveMatches.map((m: any) => ({
    match_id: m.id,
    team_a_aces: 4, team_a_blocks: 6, team_a_kills: 32, team_a_errors: 8,
    team_b_aces: 3, team_b_blocks: 4, team_b_kills: 29, team_b_errors: 11,
  }))

  if (statsData.length > 0) await admin.from('match_stats').insert(statsData)

  // Aggiungi odds
  const oddsData = insertedMatches.map((m: any) => ({
    match_id: m.id,
    market: 'winner',
    team_a_odd: parseFloat((1.5 + Math.random()).toFixed(2)),
    team_b_odd: parseFloat((1.5 + Math.random() * 1.5).toFixed(2)),
    provider: 'snai',
  }))
  await admin.from('odds').insert(oddsData)

  return NextResponse.json({ ok: true, matches: insertedMatches.length })
}
