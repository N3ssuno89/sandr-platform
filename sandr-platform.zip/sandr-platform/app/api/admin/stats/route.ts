import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'

export async function PATCH(req: Request) {
  const body = await req.json()
  const { match_id, ...stats } = body
  const admin = supabaseAdmin()
  const { data, error } = await admin
    .from('match_stats')
    .upsert({ match_id, ...stats, updated_at: new Date().toISOString() })
    .select().single()
  if (error) return NextResponse.json({ error: error.message }, { status: 500 })
  return NextResponse.json(data)
}
