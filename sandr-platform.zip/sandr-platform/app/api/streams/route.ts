import { NextResponse } from 'next/server'
import { supabaseAdmin } from '@/lib/supabase'
import { createLiveInput } from '@/lib/cloudflare'

export async function POST(req: Request) {
  const { match_id, match_title } = await req.json()

  // Crea live input su Cloudflare Stream
  const cfInput = await createLiveInput(match_title)
  if (!cfInput) return NextResponse.json({ error: 'Cloudflare error' }, { status: 500 })

  const admin = supabaseAdmin()
  const { data, error } = await admin.from('streams').insert({
    match_id,
    cloudflare_input_id: cfInput.uid,
    cloudflare_stream_key: cfInput.rtmps?.streamKey || '',
    rtmp_url: cfInput.rtmps?.url || 'rtmps://live.cloudflare.com:443/live/',
    hls_playback_url: cfInput.webRTC?.url || '',
    status: 'idle',
  }).select().single()

  if (error) return NextResponse.json({ error: error.message }, { status: 500 })

  // Aggiorna match come live
  await admin.from('matches').update({ status: 'live' }).eq('id', match_id)

  return NextResponse.json(data)
}
