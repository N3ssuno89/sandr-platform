import { Resend } from 'resend'
const resend = new Resend(process.env.RESEND_API_KEY)

export async function sendWelcomeEmail(email: string, name: string) {
  try {
    await resend.emails.send({
      from: 'SANDR <onboarding@resend.dev>',
      to: email,
      subject: 'Benvenuto su SANDR',
      html: `<div style="background:#0E0E0E;color:#F8F6F3;padding:32px;font-family:sans-serif;max-width:520px;border-radius:12px;">
        <div style="font-size:28px;font-weight:900;letter-spacing:3px;margin-bottom:20px;">S<span style="color:#F04E00">A</span>NDR</div>
        <h2>Ciao ${name}! 👋</h2>
        <p style="color:#888;margin:12px 0 20px;line-height:1.6;">Benvenuto su SANDR — la piattaforma per il beach volley.</p>
        <a href="${process.env.NEXT_PUBLIC_APP_URL}" style="background:#F04E00;color:#000;padding:12px 28px;border-radius:8px;font-weight:700;text-decoration:none;">Vai su SANDR →</a>
      </div>`,
    })
  } catch(e) { console.error('Email error:', e) }
}

export async function sendPremiumEmail(email: string, name: string) {
  try {
    await resend.emails.send({
      from: 'SANDR <onboarding@resend.dev>',
      to: email,
      subject: '★ Premium attivato — SANDR',
      html: `<div style="background:#0E0E0E;color:#F8F6F3;padding:32px;font-family:sans-serif;max-width:520px;border-radius:12px;">
        <div style="font-size:28px;font-weight:900;letter-spacing:3px;margin-bottom:20px;">S<span style="color:#F04E00">A</span>NDR</div>
        <h2>★ Premium attivato!</h2>
        <p style="color:#888;margin-top:12px;line-height:1.6;">Ora hai accesso a tutte le partite live, repliche HD e statistiche in tempo reale.</p>
      </div>`,
    })
  } catch(e) { console.error('Email error:', e) }
}
