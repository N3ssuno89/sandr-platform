const CF_ACCOUNT = process.env.CLOUDFLARE_ACCOUNT_ID!
const CF_TOKEN   = process.env.CLOUDFLARE_API_TOKEN!
const BASE = `https://api.cloudflare.com/client/v4/accounts/${CF_ACCOUNT}/stream`
const headers = {
  'Authorization': `Bearer ${CF_TOKEN}`,
  'Content-Type': 'application/json',
}

export async function createLiveInput(matchTitle: string) {
  const res = await fetch(`${BASE}/live_inputs`, {
    method: 'POST', headers,
    body: JSON.stringify({
      meta: { name: `SANDR - ${matchTitle}` },
      recording: { mode: 'automatic' },
    }),
  })
  const data = await res.json()
  return data.result
}

export async function getLiveInput(inputId: string) {
  const res = await fetch(`${BASE}/live_inputs/${inputId}`, { headers })
  const data = await res.json()
  return data.result
}

export async function listVideos() {
  const res = await fetch(`${BASE}?status=ready`, { headers })
  const data = await res.json()
  return data.result || []
}

export async function getVideo(videoId: string) {
  const res = await fetch(`${BASE}/${videoId}`, { headers })
  const data = await res.json()
  return data.result
}

export function getHlsUrl(videoId: string): string {
  return `https://customer-${CF_ACCOUNT}.cloudflarestream.com/${videoId}/manifest/video.m3u8`
}

export function getThumbnailUrl(videoId: string): string {
  return `https://customer-${CF_ACCOUNT}.cloudflarestream.com/${videoId}/thumbnails/thumbnail.jpg`
}
