'use client'
import { useState, useEffect } from 'react'
import { supabase } from '@/lib/supabase'
import type { Match } from '@/types'

export function useMatches(league?: string) {
  const [matches, setMatches] = useState<Match[]>([])
  const [loading, setLoading] = useState(true)

  const fetch = async () => {
    let query = supabase
      .from('matches')
      .select('*, streams(*), match_stats(*), odds(*)')
      .order('scheduled_at')

    if (league && league !== 'all') query = query.eq('league', league)
    const { data } = await query
    setMatches(data || [])
    setLoading(false)
  }

  useEffect(() => {
    fetch()
    // Realtime subscription per aggiornamenti live (punteggi, status)
    const channel = supabase
      .channel('matches-changes')
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'matches'
      }, () => fetch())
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'match_stats'
      }, () => fetch())
      .subscribe()

    return () => { supabase.removeChannel(channel) }
  }, [league])

  return { matches, loading, refetch: fetch }
}
