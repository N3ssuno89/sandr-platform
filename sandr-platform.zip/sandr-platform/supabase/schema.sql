-- Esegui questo file su Supabase → SQL Editor

create table profiles (
  id uuid references auth.users primary key,
  email text,
  name text,
  plan text default 'free',
  stripe_customer_id text,
  stripe_subscription_id text,
  plan_expires_at timestamptz,
  created_at timestamptz default now()
);

create table matches (
  id uuid primary key default gen_random_uuid(),
  league text not null,
  tier text,
  tournament text,
  team_a_name text,
  team_a_flag text,
  team_a_rank int,
  team_b_name text,
  team_b_flag text,
  team_b_rank int,
  scheduled_at timestamptz,
  status text default 'scheduled',
  score_sets jsonb,
  set_score text,
  is_free boolean default false,
  is_ppv boolean default false,
  ppv_price numeric default 4.99,
  court text,
  color text default '#0D2137',
  created_at timestamptz default now()
);

create table streams (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references matches on delete cascade,
  cloudflare_input_id text,
  cloudflare_stream_key text,
  rtmp_url text,
  hls_playback_url text,
  status text default 'idle',
  started_at timestamptz,
  ended_at timestamptz,
  created_at timestamptz default now()
);

create table videos (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references matches on delete set null,
  cloudflare_asset_id text,
  hls_url text,
  thumbnail_url text,
  duration_seconds int,
  type text default 'replay',
  is_free boolean default false,
  views_count int default 0,
  published_at timestamptz default now()
);

create table match_stats (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references matches on delete cascade unique,
  team_a_aces int default 0,
  team_a_blocks int default 0,
  team_a_kills int default 0,
  team_a_errors int default 0,
  team_b_aces int default 0,
  team_b_blocks int default 0,
  team_b_kills int default 0,
  team_b_errors int default 0,
  source text default 'manual',
  updated_at timestamptz default now()
);

create table odds (
  id uuid primary key default gen_random_uuid(),
  match_id uuid references matches on delete cascade,
  market text default 'winner',
  team_a_odd numeric,
  team_b_odd numeric,
  provider text default 'snai',
  updated_at timestamptz default now()
);

create table ppv_purchases (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users on delete cascade,
  match_id uuid references matches on delete cascade,
  stripe_payment_intent_id text,
  amount numeric,
  purchased_at timestamptz default now()
);

-- RLS
alter table profiles enable row level security;
alter table ppv_purchases enable row level security;
alter table matches enable row level security;
alter table videos enable row level security;
alter table match_stats enable row level security;
alter table odds enable row level security;
alter table streams enable row level security;

create policy "Users see own profile" on profiles for all using (auth.uid() = id);
create policy "Users see own purchases" on ppv_purchases for all using (auth.uid() = user_id);
create policy "Public read matches" on matches for select using (true);
create policy "Public read videos" on videos for select using (true);
create policy "Public read stats" on match_stats for select using (true);
create policy "Public read odds" on odds for select using (true);
create policy "Public read streams" on streams for select using (true);

-- Service role can write everything (usato dalle API routes)
create policy "Service insert matches" on matches for insert with check (true);
create policy "Service update matches" on matches for update using (true);
create policy "Service insert streams" on streams for insert with check (true);
create policy "Service insert stats" on match_stats for insert with check (true);
create policy "Service update stats" on match_stats for update using (true);
create policy "Service insert odds" on odds for insert with check (true);
create policy "Service insert videos" on videos for insert with check (true);

-- Trigger: crea profilo al signup
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, email)
  values (new.id, new.email);
  return new;
end;
$$ language plpgsql security definer;

create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();
