'use client'
import { useEffect, useRef, useState } from 'react'

interface Props {
  hlsUrl: string
  isLive?: boolean
  autoPlay?: boolean
}

export function VideoPlayer({ hlsUrl, isLive = false, autoPlay = true }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [error, setError] = useState(false)

  useEffect(() => {
    if (!videoRef.current || !hlsUrl) return

    const video = videoRef.current

    const loadHls = async () => {
      try {
        const Hls = (await import('hls.js')).default
        if (Hls.isSupported()) {
          const hls = new Hls({ enableWorker: true, lowLatencyMode: isLive })
          hls.loadSource(hlsUrl)
          hls.attachMedia(video)
          hls.on(Hls.Events.ERROR, (_, data) => {
            if (data.fatal) setError(true)
          })
          return () => hls.destroy()
        } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
          // Safari native HLS
          video.src = hlsUrl
        }
      } catch {
        setError(true)
      }
    }

    loadHls()
  }, [hlsUrl, isLive])

  if (error) {
    return (
      <div style={{
        width:'100%',aspectRatio:'16/9',
        background:'linear-gradient(135deg,#020D1A,#0A3A5A)',
        display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
        gap:8,color:'rgba(255,255,255,.3)',
      }}>
        <div style={{fontSize:48}}>🏐</div>
        <div style={{fontSize:11,letterSpacing:2}}>
          {isLive ? 'STREAM NON DISPONIBILE' : 'VIDEO NON DISPONIBILE'}
        </div>
      </div>
    )
  }

  return (
    <video
      ref={videoRef}
      autoPlay={autoPlay}
      controls
      playsInline
      muted={isLive}
      style={{ width:'100%', aspectRatio:'16/9', background:'#000', display:'block' }}
    />
  )
}
