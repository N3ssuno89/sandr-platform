'use client'

export function LiveBadge() {
  return (
    <span style={{
      display:'inline-flex',alignItems:'center',gap:4,
      background:'#FF3535',color:'#fff',
      fontSize:9,fontWeight:800,letterSpacing:1,
      padding:'2px 7px',borderRadius:3,
    }}>
      <span style={{
        width:5,height:5,borderRadius:'50%',background:'#fff',
        animation:'bk 1s infinite',flexShrink:0
      }}/>
      LIVE
      <style>{`@keyframes bk{0%,100%{opacity:1}50%{opacity:.25}}`}</style>
    </span>
  )
}

export function FreeTag() {
  return (
    <span style={{
      display:'inline-flex',alignItems:'center',
      background:'rgba(34,212,90,.15)',color:'#22D45A',
      fontSize:9,fontWeight:800,letterSpacing:.7,
      padding:'2px 7px',borderRadius:3,
      border:'1px solid rgba(34,212,90,.25)',
    }}>FREE</span>
  )
}

export function PremTag() {
  return (
    <span style={{
      display:'inline-flex',alignItems:'center',
      background:'rgba(240,78,0,.15)',color:'#F04E00',
      fontSize:9,fontWeight:800,letterSpacing:.7,
      padding:'2px 7px',borderRadius:3,
      border:'1px solid rgba(240,78,0,.3)',
    }}>★ PREMIUM</span>
  )
}
