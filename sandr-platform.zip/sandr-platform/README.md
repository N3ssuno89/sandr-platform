# SANDR Platform

Piattaforma streaming per beach volley e sand sports.

## Stack
- **Next.js 14** — framework
- **Supabase** — database, auth, realtime
- **Cloudflare Stream** — video live e replay
- **Stripe** — abbonamenti e PPV
- **Resend** — email transazionali
- **Netlify** — hosting e deploy

## Setup locale

```bash
# 1. Clona il repo
git clone https://github.com/TUO-USERNAME/sandr-platform.git
cd sandr-platform

# 2. Installa dipendenze
npm install

# 3. Copia le env variables
cp .env.example .env.local
# Riempi .env.local con le tue chiavi

# 4. Esegui lo schema SQL su Supabase
# Vai su Supabase → SQL Editor → incolla il contenuto di supabase/schema.sql

# 5. Avvia in sviluppo
npm run dev
```

## Deploy su Netlify

1. Push su GitHub
2. Netlify → New site → Import from GitHub → seleziona `sandr-platform`
3. Build command: `npm run build`
4. Publish directory: `.next`
5. Aggiungi le env variables su Netlify → Site Settings → Environment Variables
6. Installa il plugin: `@netlify/plugin-nextjs`

## Prima esecuzione

Una volta in produzione, vai su `/` → clicca **"Carica dati demo"** per popolare il database con partite di esempio.

## Admin

Per aggiornare punteggi, creare live stream e gestire partite usa l'API direttamente:

```bash
# Crea una partita
POST /api/matches

# Aggiorna punteggio
PATCH /api/matches/:id
{ "score_sets": [{"a":21,"b":19},{"a":18,"b":21},{"a":10,"b":6}], "set_score": "2-1" }

# Crea stream live (genera RTMP key da Cloudflare)
POST /api/streams
{ "match_id": "uuid", "match_title": "Åhman/Hellvig vs Mol/Sørum" }

# Aggiorna statistiche
PATCH /api/admin/stats
{ "match_id": "uuid", "team_a_aces": 4, "team_b_aces": 3, ... }
```

## Struttura

```
app/
  page.tsx              ← App principale
  api/
    matches/            ← CRUD partite
    streams/            ← Gestione live stream
    videos/             ← Repliche
    auth/signup/        ← Registrazione
    admin/seed/         ← Dati demo
    admin/stats/        ← Aggiornamento statistiche
lib/
  supabase.ts           ← Client Supabase
  cloudflare.ts         ← API Cloudflare Stream
  resend.ts             ← Email
components/
  ui/tags.tsx           ← Badge Live/Free/Premium
  player/VideoPlayer.tsx ← Player HLS reale
hooks/
  useMatches.ts         ← Hook con realtime
  useAuth.ts            ← Hook auth
types/index.ts          ← TypeScript types
```
