/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['customer-*.cloudflarestream.com', 'videodelivery.net'],
  },
}
module.exports = nextConfig
