export type Plan = 'free' | 'premium'

export interface Profile {
  id: string
  email: string
  name: string | null
  plan: Plan
  stripe_customer_id: string | null
  plan_expires_at: string | null
  created_at: string
}

export interface Match {
  id: string
  league: string
  tier: string
  tournament: string
  team_a_name: string
  team_a_flag: string
  team_a_rank: number
  team_b_name: string
  team_b_flag: string
  team_b_rank: number
  scheduled_at: string
  status: 'scheduled' | 'live' | 'completed' | 'cancelled'
  score_sets: Array<{a:number, b:number}> | null
  set_score: string | null
  is_free: boolean
  is_ppv: boolean
  ppv_price: number
  court: string | null
  color: string
}

export interface Stream {
  id: string
  match_id: string
  cloudflare_input_id: string
  cloudflare_stream_key: string
  rtmp_url: string
  hls_playback_url: string
  status: 'idle' | 'live' | 'ended'
}

export interface Video {
  id: string
  match_id: string | null
  cloudflare_asset_id: string
  hls_url: string
  thumbnail_url: string | null
  duration_seconds: number | null
  type: 'replay' | 'highlight' | 'clip'
  is_free: boolean
  views_count: number
  published_at: string
  match?: Match
}

export interface MatchStats {
  id: string
  match_id: string
  team_a_aces: number
  team_a_blocks: number
  team_a_kills: number
  team_a_errors: number
  team_b_aces: number
  team_b_blocks: number
  team_b_kills: number
  team_b_errors: number
}

export interface Odds {
  id: string
  match_id: string
  market: string
  team_a_odd: number
  team_b_odd: number
  provider: string
}
